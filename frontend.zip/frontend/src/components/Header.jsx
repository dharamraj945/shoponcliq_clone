import React from "react";
import Logo from "./Assets/images/logo.avif";
import { FaSearch } from "react-icons/fa";
import { FaUser } from "react-icons/fa";
import { FaShoppingBag } from "react-icons/fa";

export default function Header() {
  return (
    <>
      {/* anouncment bar */}

      <div className="bg-blue-800 text-center">
        <p className="py-2 text-white">Welcome to our store</p>
      </div>

      {/* anouncment bar */}

      <div className="bg-white-200  py-5 flex items-center justify-center w-500	">
        {/* header */}

        <div className="  bg-white-200 flex items-center justify-between 	">
          <div className="flex items-center ">
            <div className="mx-10">
              <img className="w-44" src={Logo} alt="" />
            </div>
            <div className="navtext">
              <ul className="flex">
                <a href="">
                  {" "}
                  <li className="mr-5">Designer Case</li>
                </a>
                <a href="">
                  {" "}
                  <li className="mr-5"> Glass Cases</li>
                </a>
                <a href="">
                  <li className="mr-5">Silicon Cases</li>
                </a>
                <a href="">
                  <li className="mr-5">EyeWear</li>
                </a>
                <a href="">
                  <li className="mr-5">Woman Ethic Wear</li>
                </a>
                <a href="">
                  <li className="mr-5">Other</li>
                </a>
              </ul>
            </div>
          </div>
          <div className="flex items-right ml-52 ">
            <div className="flex  ">
              <a className="mx-4" href="">
                <FaSearch />
              </a>
              <a className="mx-4" href="">
                <FaUser />
              </a>
              <a className="mx-4">
                <FaShoppingBag />
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
