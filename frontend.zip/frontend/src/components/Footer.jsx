import React from "react";
import { FaFacebookSquare } from "react-icons/fa";
import { FaPinterest } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa";
import { FaYoutube } from "react-icons/fa";

const Footer = () => {
  return (
    <div>
      <div className="bg-gray-200 py-5">
        <div className="flex items-left justify-around">
          {/* quick Links  */}

          <div>
            <h2 className="mb-6">
              {" "}
              <strong> Quick links</strong>
            </h2>

            <ul>
              <li className="mb-5">
                <a href="">About Us</a>
              </li>
              <li className="mb-5">
                <a href="">Contact US</a>
              </li>
              <li className="mb-5">
                <a href="">Terms of Service</a>
              </li>
              <li className="mb-5">
                <a href="">Privacy Policy</a>
              </li>
              <li className="mb-5">
                <a href="">Exchange / Refund Policy</a>
              </li>
              <li className="mb-5">
                <a href="">Cancel Order</a>
              </li>
              <li className="mb-5">
                <a href="">Shipping Policy</a>
              </li>
              <li className="mb-5">
                <a href="">Blogs</a>
              </li>
              <li className="mb-5">
                <a href="">Track Your Order</a>
              </li>
            </ul>
          </div>
          {/* quick Links  */}

          {/* get in touch  */}

          <div>
            <h2 className="mb-6">
              {" "}
              <strong> GET IN TOUCH</strong>
            </h2>

            <ul>
              <p>
                Address : 28/132, Ground Floor, West Patel Nagar, New Delhi
                -110008
              </p>
              <p>
                <strong> Mail:</strong> support@shoponcliq.com
              </p>
              <p>Ph : 9266887788 ( Mon To Sat 10 A.M to 6 P.M)</p>
            </ul>
          </div>
          {/* get in touch  */}
        </div>

        <div className="detail-footer flex items-center text-left justify-around">
          <div>
            <h1>Subscribe to our emails</h1>
            <input
              className=" pl-2 w-30 pr-10 py-2"
              type="text"
              placeholder="Email"
            />
          </div>
          <div className="flex">
            <a className="mx-4" href="">
              <FaFacebookSquare />
            </a>
            <a className="mx-4" href="">
              <FaPinterest />
            </a>{" "}
            <a className="mx-4" href="">
              <FaInstagram />
            </a>{" "}
            <a className="mx-4" href="">
              <FaYoutube />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
