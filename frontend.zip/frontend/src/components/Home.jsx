import React from "react";
import Slider from "./Slider";

const Home = () => {
  return (
    <div>
      <>
        <Slider />

        <div className="mx-5 my-5">
          <h1>this is home</h1>
        </div>
      </>
    </div>
  );
};

export default Home;
