import React from "react";

const DesignerCases = () => {
  return (
    <div>
      <h1>This Is Designer Case page</h1>
    </div>
  );
};

export default DesignerCases;
